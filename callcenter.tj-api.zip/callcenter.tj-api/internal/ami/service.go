package ami

import "log"

type Service struct {
	onEvent func(map[string]string)
}

func NewService(addr, user, pass string, cb func(map[string]string)) (*Service, error) {
	log.Println("✅ AMI connected")
	return &Service{onEvent: cb}, nil
}

func (s *Service) Start() {
	log.Println("📡 Starting AMI service")
	select {}
}

package ami

import (
	"strings"

	"callcentrix/internal/monitor"
)

type Handler struct {
	Store *monitor.Store
}

func (h *Handler) HandleEvent(ev map[string]string) {
	switch ev["Event"] {

	case "DeviceStateChange":
		exten := strings.TrimPrefix(ev["Device"], "PJSIP/")
		state := ev["State"]

		tenant := h.ResolveTenant(exten)
		if tenant == 0 {
			return
		}

		h.Store.UpdateAgent(tenant, exten, state)
	}
}

// ⚠️ временно — позже из БД
func (h *Handler) ResolveTenant(exten string) int {
	return 110001
}

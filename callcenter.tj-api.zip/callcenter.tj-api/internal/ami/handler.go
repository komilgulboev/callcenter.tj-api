package ami

import (
	"log"
	"strconv"
	"time"

	"callcentrix/internal/monitor"
)

type Handler struct {
	Agents   *monitor.Store
	Calls    *monitor.CallStore
	Resolver *monitor.TenantResolver
}

func (h *Handler) HandleEvent(event map[string]string) {
	eventName := event["Event"]
	log.Println("AMI RAW EVENT:", event)

	switch eventName {

	// ======================
	// AGENT STATE
	// ======================
	case "DeviceStateChange":
		device := event["Device"] // PJSIP/110002
		state := event["State"]

		exten := parseExten(device)
		if exten == "" {
			return
		}

		tenantID, ok := h.Resolver.Resolve(exten)
		if !ok {
			return
		}

		h.Agents.UpdateAgent(tenantID, exten, state)

	// ======================
	// NEW CALL
	// ======================
	case "Newchannel":
		linkedid := event["Linkedid"]
		from := event["CallerIDNum"]
		to := event["Exten"]

		if linkedid == "" || from == "" || to == "" {
			return
		}

		tenantID, ok := h.Resolver.Resolve(to)
		if !ok {
			return
		}

		h.Calls.Upsert(monitor.Call{
			ID:        linkedid,
			From:      from,
			To:        to,
			State:     monitor.CallRinging,
			TenantID:  tenantID,
			StartTime: time.Now().Unix(),
		})

	// ======================
	// CALL ANSWERED
	// ======================
	case "BridgeEnter":
		linkedid := event["Linkedid"]
		exten := event["Exten"]

		tenantID, ok := h.Resolver.Resolve(exten)
		if !ok {
			return
		}

		h.Calls.Upsert(monitor.Call{
			ID:        linkedid,
			State:     monitor.CallActive,
			TenantID:  tenantID,
			StartTime: time.Now().Unix(),
		})

	// ======================
	// CALL END
	// ======================
	case "Hangup":
		linkedid := event["Linkedid"]
		exten := event["Exten"]

		tenantID, ok := h.Resolver.Resolve(exten)
		if !ok {
			return
		}

		h.Calls.End(tenantID, linkedid)
	}
}

func parseExten(device string) string {
	for i := len(device) - 1; i >= 0; i-- {
		if device[i] == '/' {
			return device[i+1:]
		}
	}
	return ""
}

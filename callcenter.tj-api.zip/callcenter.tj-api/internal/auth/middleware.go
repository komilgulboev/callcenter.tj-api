package auth

import (
	"context"
	"net/http"
	"strings"

	"github.com/golang-jwt/jwt/v5"
)

type contextKey string

const userContextKey contextKey = "user"

func Middleware(secret string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

			h := r.Header.Get("Authorization")
			if !strings.HasPrefix(h, "Bearer ") {
				http.Error(w, "unauthorized", 401)
				return
			}

			tokenStr := strings.TrimPrefix(h, "Bearer ")

			token, err := jwt.Parse(tokenStr, func(t *jwt.Token) (any, error) {
				return []byte(secret), nil
			})

			if err != nil || !token.Valid {
				http.Error(w, "invalid token", 401)
				return
			}

			claims := token.Claims.(jwt.MapClaims)

			ctx := context.WithValue(r.Context(), userContextKey, AuthContext{
				UserID:   int(claims["sub"].(float64)),
				Username: claims["username"].(string),
				TenantID: int(claims["tenantId"].(float64)),
				UserType: int(claims["userType"].(float64)),
			})

			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

func FromContext(ctx context.Context) AuthContext {
	return ctx.Value(userContextKey).(AuthContext)
}

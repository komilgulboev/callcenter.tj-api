package auth

type AuthContext struct {
	UserID   int
	Username string
	TenantID int
	UserType int
}

package ws

import (
	"log"
	"net/http"

	"github.com/gorilla/websocket"

	"callcentrix/internal/auth"
	"callcentrix/internal/monitor"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool { return true },
}

func Monitor(store *monitor.Store) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		user := auth.FromContext(r.Context())
		tenant := user.TenantID

		conn, err := upgrader.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer conn.Close()

		log.Println("🔌 WS CONNECT tenant:", tenant)

		conn.WriteJSON(map[string]any{
			"type": "snapshot",
			"data": store.GetAllByTenant(tenant),
		})

		sub := store.Subscribe(tenant)
		defer store.Unsubscribe(tenant, sub)

		for agent := range sub {
			conn.WriteJSON(map[string]any{
				"type": "update",
				"data": agent,
			})
		}
	}
}

package ws

import (
	"log"
	"net/http"

	"github.com/gorilla/websocket"

	"callcentrix/internal/auth"
	"callcentrix/internal/config"
	"callcentrix/internal/monitor"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool { return true },
}

func Monitor(
	agentStore *monitor.Store,
	callStore *monitor.CallStore,
	cfg *config.Config,
) http.HandlerFunc {

	return func(w http.ResponseWriter, r *http.Request) {
		// 🔐 JWT из query (?token=)
		token := r.URL.Query().Get("token")
		if token == "" {
			http.Error(w, "missing token", http.StatusUnauthorized)
			return
		}

		user, err := auth.ParseJWT(token, cfg.JWT.Secret)
		if err != nil {
			http.Error(w, "invalid token", http.StatusUnauthorized)
			return
		}

		tenantID := user.TenantID

		conn, err := upgrader.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer conn.Close()

		log.Println("🔌 WS CONNECT tenant:", tenantID)

		// =======================
		// SNAPSHOT
		// =======================
		conn.WriteJSON(map[string]any{
			"type": "snapshot",
			"data": map[string]any{
				"agents": agentStore.Snapshot(tenantID),
				"calls":  callStore.Snapshot(tenantID),
			},
		})

		agentSub := agentStore.Subscribe(tenantID)
		callSub := callStore.Subscribe(tenantID)

		defer agentStore.Unsubscribe(tenantID, agentSub)
		defer callStore.Unsubscribe(tenantID, callSub)

		for {
			select {
			case agent := <-agentSub:
				conn.WriteJSON(map[string]any{
					"type": "agent_update",
					"data": agent,
				})

			case call := <-callSub:
				if call.State == monitor.CallEnded {
					conn.WriteJSON(map[string]any{
						"type": "call_end",
						"data": call,
					})
				} else {
					conn.WriteJSON(map[string]any{
						"type": "call_update",
						"data": call,
					})
				}
			}
		}
	}
}

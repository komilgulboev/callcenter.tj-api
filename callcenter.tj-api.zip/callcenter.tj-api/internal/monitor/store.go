package monitor

import "sync"

type Subscriber chan AgentState

type Store struct {
	mu          sync.RWMutex
	agents      map[int]map[string]AgentState
	subscribers map[int][]Subscriber
}

func NewStore() *Store {
	return &Store{
		agents:      make(map[int]map[string]AgentState),
		subscribers: make(map[int][]Subscriber),
	}
}

func (s *Store) UpdateAgent(tenant int, exten string, state string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.agents[tenant]; !ok {
		s.agents[tenant] = make(map[string]AgentState)
	}

	agent := AgentState{
		Exten: exten,
		State: state,
	}

	s.agents[tenant][exten] = agent

	for _, sub := range s.subscribers[tenant] {
		select {
		case sub <- agent:
		default:
		}
	}
}

func (s *Store) GetAllByTenant(tenant int) []AgentState {
	s.mu.RLock()
	defer s.mu.RUnlock()

	var res []AgentState
	for _, a := range s.agents[tenant] {
		res = append(res, a)
	}
	return res
}

func (s *Store) Subscribe(tenant int) Subscriber {
	s.mu.Lock()
	defer s.mu.Unlock()

	ch := make(Subscriber, 10)
	s.subscribers[tenant] = append(s.subscribers[tenant], ch)
	return ch
}

func (s *Store) Unsubscribe(tenant int, ch Subscriber) {
	s.mu.Lock()
	defer s.mu.Unlock()

	subs := s.subscribers[tenant]
	for i, sub := range subs {
		if sub == ch {
			s.subscribers[tenant] = append(subs[:i], subs[i+1:]...)
			close(ch)
			break
		}
	}
}

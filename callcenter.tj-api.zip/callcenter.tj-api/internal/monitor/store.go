package monitor

import "sync"

type Store struct {
	mu      sync.RWMutex
	tenants map[string]*TenantState
}

type TenantState struct {
	Queues map[string]*Queue
	Agents map[string]*Agent
	Calls  map[string]*Call
}

func NewStore() *Store {
	return &Store{
		tenants: make(map[string]*TenantState),
	}
}

// ---------- tenant helpers ----------

func (s *Store) getTenant(tenantId string) *TenantState {
	if tenantId == "" {
		return nil
	}

	t, ok := s.tenants[tenantId]
	if !ok {
		t = &TenantState{
			Queues: make(map[string]*Queue),
			Agents: make(map[string]*Agent),
			Calls:  make(map[string]*Call),
		}
		s.tenants[tenantId] = t
	}
	return t
}

// ---------- queues ----------

func (s *Store) SetQueue(tenantId, queue string, state *Queue) {
	s.mu.Lock()
	defer s.mu.Unlock()

	t := s.getTenant(tenantId)
	if t == nil {
		return
	}
	t.Queues[queue] = state
}

func (s *Store) GetQueues(tenantId string) map[string]*Queue {
	s.mu.RLock()
	defer s.mu.RUnlock()

	t := s.tenants[tenantId]
	if t == nil {
		return map[string]*Queue{}
	}

	out := make(map[string]*Queue)
	for k, v := range t.Queues {
		out[k] = v
	}
	return out
}

// ---------- agents ----------

func (s *Store) SetAgent(tenantId, agent string, state *Agent) {
	s.mu.Lock()
	defer s.mu.Unlock()

	t := s.getTenant(tenantId)
	if t == nil {
		return
	}
	t.Agents[agent] = state
}

func (s *Store) GetAgents(tenantId string) map[string]*Agent {
	s.mu.RLock()
	defer s.mu.RUnlock()

	t := s.tenants[tenantId]
	if t == nil {
		return map[string]*Agent{}
	}

	out := make(map[string]*Agent)
	for k, v := range t.Agents {
		out[k] = v
	}
	return out
}

// ---------- calls ----------

func (s *Store) SetCall(tenantId, callId string, state *Call) {
	s.mu.Lock()
	defer s.mu.Unlock()

	t := s.getTenant(tenantId)
	if t == nil {
		return
	}
	t.Calls[callId] = state
}

func (s *Store) RemoveCall(tenantId, callId string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	t := s.tenants[tenantId]
	if t == nil {
		return
	}
	delete(t.Calls, callId)
}

func (s *Store) GetCalls(tenantId string) map[string]*Call {
	s.mu.RLock()
	defer s.mu.RUnlock()

	t := s.tenants[tenantId]
	if t == nil {
		return map[string]*Call{}
	}

	out := make(map[string]*Call)
	for k, v := range t.Calls {
		out[k] = v
	}
	return out
}

package monitor

import "sync"

// =======================
// QUEUE MODEL
// =======================

type QueueStats struct {
	Name   string `json:"name"`
	Calls  int    `json:"calls"`
	Missed int    `json:"missed"`
}

// =======================
// QUEUE STORE
// =======================

type QueueStore struct {
	mu     sync.RWMutex
	queues map[int]*QueueStats // tenantID → queue
}

func NewQueueStore() *QueueStore {
	return &QueueStore{
		queues: make(map[int]*QueueStats),
	}
}

// =======================
// UPDATE
// =======================

func (s *QueueStore) Ensure(tenantID int) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.queues[tenantID]; !ok {
		s.queues[tenantID] = &QueueStats{
			Name:   "Queue " + string(rune(tenantID)),
			Calls:  0,
			Missed: 0,
		}
	}
}

func (s *QueueStore) IncCalls(tenantID int) {
	s.Ensure(tenantID)
	s.mu.Lock()
	s.queues[tenantID].Calls++
	s.mu.Unlock()
}

func (s *QueueStore) DecCalls(tenantID int) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if q, ok := s.queues[tenantID]; ok && q.Calls > 0 {
		q.Calls--
	}
}

func (s *QueueStore) IncMissed(tenantID int) {
	s.Ensure(tenantID)
	s.mu.Lock()
	s.queues[tenantID].Missed++
	s.mu.Unlock()
}

// =======================
// SNAPSHOT
// =======================

func (s *QueueStore) Snapshot(tenantID int) *QueueStats {
	s.mu.RLock()
	defer s.mu.RUnlock()

	if q, ok := s.queues[tenantID]; ok {
		copy := *q
		return &copy
	}
	return nil
}

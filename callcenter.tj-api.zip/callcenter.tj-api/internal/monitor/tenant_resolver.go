package monitor

import (
	"database/sql"
	"log"
	"sync"
)

type TenantResolver struct {
	mu    sync.RWMutex
	cache map[string]int // exten -> tenantID
	db    *sql.DB
}

func NewTenantResolver(db *sql.DB) *TenantResolver {
	return &TenantResolver{
		cache: make(map[string]int),
		db:    db,
	}
}

func (r *TenantResolver) Resolve(exten string) (int, bool) {
	r.mu.RLock()
	if t, ok := r.cache[exten]; ok {
		r.mu.RUnlock()
		return t, true
	}
	r.mu.RUnlock()

	// 🔥 запрос в БД
	var tenantID int
	err := r.db.QueryRow(`
		SELECT tenant_id
		FROM ast_ps_endpoints
		WHERE id = $1
	`, exten).Scan(&tenantID)

	if err != nil {
		log.Println("❌ tenant resolve failed for", exten, err)
		return 0, false
	}

	r.mu.Lock()
	r.cache[exten] = tenantID
	r.mu.Unlock()

	log.Println("✅ tenant resolved:", exten, "→", tenantID)
	return tenantID, true
}

package monitor

import (
	"sync"
	"time"
)

// =========================
// CALL MODEL
// =========================

type Call struct {
	ID        string    `json:"id"`
	From      string    `json:"from"`
	To        string    `json:"to"`
	Channel   string    `json:"channel"`
	StartedAt time.Time `json:"startedAt"`
}

// =========================
// CALL STORE
// =========================

type CallStore struct {
	mu    sync.RWMutex
	calls map[int]map[string]Call // tenantID → callID → Call
}

func NewCallStore() *CallStore {
	return &CallStore{
		calls: make(map[int]map[string]Call),
	}
}

// =========================
// PUBLIC API
// =========================

func (s *CallStore) UpdateCall(tenantID int, call Call) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.calls[tenantID] == nil {
		s.calls[tenantID] = make(map[string]Call)
	}

	// если звонок новый — фиксируем старт
	if _, ok := s.calls[tenantID][call.ID]; !ok {
		call.StartedAt = time.Now()
	} else {
		call.StartedAt = s.calls[tenantID][call.ID].StartedAt
	}

	s.calls[tenantID][call.ID] = call
}

func (s *CallStore) RemoveCall(tenantID int, callID string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.calls[tenantID]; !ok {
		return
	}

	delete(s.calls[tenantID], callID)
}

func (s *CallStore) GetCalls(tenantID int) map[string]Call {
	s.mu.RLock()
	defer s.mu.RUnlock()

	out := make(map[string]Call)
	for k, v := range s.calls[tenantID] {
		out[k] = v
	}
	return out
}

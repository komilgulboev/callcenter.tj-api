package monitor

type AgentState struct {
	Exten string `json:"exten"`
	State string `json:"state"`
	Calls int    `json:"calls"`
}
